Stefan Theard Peoplesoft ID: 1208198
Cosc 2320

This program is a doubly linked list implementation that will take an input of a scriptfile
with several commands: read, write, insert, and delete. Write can be both forward and reverse.
This program will perform these operations by first initializing a list, and then using the
ScriptParser class to parse commands from the script file one by one. These will be handled in order
and will throw errors to a log.txt as they come. The program will terminate if a file cannot be read
with the initial read command. The program will output in bytes the size of the list throughout it's
execution to the log file as well. 
