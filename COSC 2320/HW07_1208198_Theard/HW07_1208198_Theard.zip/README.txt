Stefan Theard PSID: 1208198

Page Rank (HW07)

This program uses arrays, linked lists, and an adjacency list to build a graph of vertices and edges by parsing html files for their anchor links. The program evaluates the indegree and outdegree of each given html file and then outputs the top 5 ranked in order from highest indegree. The program also ouputs any broken links or sinks out of a given filelist.

