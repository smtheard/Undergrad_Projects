Stefan Theard Peoplesoft ID: 1208198
Cosc 2320

hw03 stacks
expressions

This program is a stack implementation that does infix to postfix conversion by using a singly linked stack
and storing the postfix list into a linked list. It also uses a singly linked stack for postfix evaluation
The program supports + (which denotes union), * (which denotes intersection), and parenthesis as separators/precedence
settings. 