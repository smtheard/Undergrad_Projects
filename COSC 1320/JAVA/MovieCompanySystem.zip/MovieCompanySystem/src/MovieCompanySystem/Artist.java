/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hw1;

 
import java.io.*;
public class Artist implements Serializable {

    String name;

    public Artist() {
    }

    public Artist(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
