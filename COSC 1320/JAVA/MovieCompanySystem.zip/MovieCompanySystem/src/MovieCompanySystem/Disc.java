/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hw1;

// Added to allow implementation of Serializable

import java.io.*;
 
public class Disc extends Track implements Serializable {

    Artist artist;
    String catalogNumber;
    public static int MAX_TRACKS = 10;
    Track[] tracks = new Track[MAX_TRACKS];
    int numberOfTracks;

    public Disc() {
    }

    public Disc(Artist artist, String CatalogNumber, String title) {
        this.catalogNumber = CatalogNumber;
        this.title = title;
        this.artist = artist;
    }

    public String getCatalogNumber() {
        return catalogNumber;
    }

    public Artist getArtist() {
        return artist;
    }

    public int getNumberofTracks() {
        // This line was bugged
        // Case sensitivity issue
        return numberOfTracks;
    }

    public Track[] getTracks() {
        return tracks;
    }

    public void addTrack(Track track) {
        tracks[numberOfTracks] = track;
        numberOfTracks++;
    }
}

