/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hw1;

 

import java.io.*;


public class Catalog implements Serializable
{

    public Artist[] artists;
    public Disc[] discs;
    
}
