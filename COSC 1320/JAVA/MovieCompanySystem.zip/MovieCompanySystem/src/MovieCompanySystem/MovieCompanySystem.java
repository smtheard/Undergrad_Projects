/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hw1;

 
public class driver {
/**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    
        // Step 4.1
        // Instantiate Controller
        Controller control = new Controller();

        // Step 4.2
        // Add Artist
        control.UCAddArtist("Miles Davis");

        // Step 4.3
        // Add Disc for this artist
        control.UCAddDisc("Miles Davis", "CD01", "Tutu");

        // Step 4.4
        // Add track for this disc
        control.UCAddTrack("CD01", "Portia", 3.34);

        // Step 4.5
        // List artists
        control.UCListArtists();

        // Step 4.5
        // List discs
        control.UCListDiscs();

        // Step 4.6
        // List tracks for disc BN01
        control.UCListTracksForDisc("BN01");

        // Step 4.7
        // Add tutu
        control.UCAddTrack("CD01", "Tutu", 4.56);

        // Step 4.7
        // Add Tomaas
        control.UCAddTrack("CD01", "Tomaas", 3.56);

        // Step 4.7
         // Add Disc for this artist
        control.UCAddDisc("Miles Davis", "CD02", "Kind of Blue");

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD02", "So What", 4.54);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD02", "Freddie Freeloader", 5.25);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD02", "Blue in Green", 2.56);

        // Step 4.7
        // Add Artist
        control.UCAddArtist("John Coltrane");

        // Step 4.7
        // Add Disc for this artist
        control.UCAddDisc("John Coltrane", "CD03", "Blue Train");

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD03", "Blue Train", 5.15);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD03", "Moments Notice", 5.52);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD03", "Locomotion", 6.18);




/*
        // Step 6.1
        // Instantiate Controller
        Controller control = new Controller();

        // Step 6.2
        // Add Artist
        control.UCAddArtist("Miles Davis");

        // Step 6.2
        // Add Disc for this artist
        control.UCAddDisc("Miles Davis", "CD01", "Tutu");

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD01", "Portia", 3.34);

        // Step 6.2
        // Add tutu
        control.UCAddTrack("CD01", "Tutu", 4.56);

        // Step 6.2
        // Add Tomaas
        control.UCAddTrack("CD01", "Tomaas", 3.56);

        // Step 6.2
        // Add Disc for this artist
        control.UCAddDisc("Miles Davis", "CD02", "Kind of Blue");

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD02", "So What", 4.54);

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD02", "Freddie Freeloader", 5.25);

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD02", "Blue in Green", 2.56);

        // Step 6.2
        // Add Artist
        control.UCAddArtist("John Coltrane");

        // Step 6.2
        // Add Disc for this artist
        control.UCAddDisc("John Coltrane", "CD03", "Blue Train");

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD03", "Blue Train", 5.15);

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD03", "Moments Notice", 5.52);

        // Step 6.2
        // Add track for this disc
        control.UCAddTrack("CD03", "Locomotion", 6.18);

        // Step 6.3
        // Save catalog
        control.saveCatalog();
*/

 /*
        // Step 6.4
        // Instantiate Controller
        Controller control = new Controller();

        // Step 6.5
        // List discs
        control.UCListDiscs();

        // Step 6.6
        // List discs
        control.restoreCatalog();

        // Step 6.7
        // List discs
        control.UCListDiscs();
   */

    }
}
