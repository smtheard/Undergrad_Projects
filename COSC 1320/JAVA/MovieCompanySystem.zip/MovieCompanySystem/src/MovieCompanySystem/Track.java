/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hw1;
import java.io.*;

 
public class Track implements Serializable{
    
    String title;
    double time;

  public Track() {  }

    public Track(String title) {
        this.title = title;
    }

    public Track(double time) {
        this.time = time;
    }

    public Track(String title, double time) {
        this.title = title;
        this.time = time;
    }

    public double getTime() {
        return time;
    }

    public String getTitle() {
        return title;
    }
}
