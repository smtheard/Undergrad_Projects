/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hw1;
import java.io.*;
 
public class Controller {
    // constants
    private final int MAX_ARTISTS = 10;
    private final int MAX_DISCS = 30;
    // variables
    public Artist[] artists = new Artist[MAX_ARTISTS];
    public int numberOfArtists = 0;
    public Disc[] discs = new Disc[MAX_DISCS];
    public int numberOfDiscs = 0;

    /**
    * adds a new Artist with a specified name
    *
    * @param artistName string containing the name
    */
    public void UCAddArtist(String artistName)
    {
        if (numberOfArtists < MAX_ARTISTS)
        {
            artists[numberOfArtists] = new Artist(artistName);
            numberOfArtists++;
            System.out.println("new Artist added");
        }
        else
            System.out.println("cannot add Artist");
    }

    /**
    * adds a new Disc with a specified name to
    * a specified Artist
    *
    * @param artistName string containing the Artist name
    * @param discCatalogNumber string containing the new
    * Disc catalog number
    * @param discTitle string containing the new Disc
    * title
    */
    public void UCAddDisc(String artistName, String discCatalogNumber,String discTitle)
    {
        Artist result = getArtistForName(artistName);
        if (result != null)
        {
            Disc theDisc = new Disc(result,
            discCatalogNumber, discTitle);
            if (numberOfDiscs < MAX_DISCS)
            {
                discs[numberOfDiscs] = theDisc;
                numberOfDiscs++;
                System.out.println("new Disc added");
            }
            else
                System.out.println("cannot add Disc");
        }
        else
            System.out.println("Artist not found");
    }

    /**
    * adds a new Track with a specified name to
    * a specified Disc
    *
    * @param discCatalogNumber string containing the
    * Disc catalog number
    * @param trackTitle string containing the Track title
    * @param time new Track time
    */
    public void UCAddTrack(String discCatalogNumber, String trackTitle, double time)
    {
        Disc result = getDiscForCatalogNumber(discCatalogNumber);
        if (result != null)
        {
            if (result.numberOfTracks < Disc.MAX_TRACKS)
            {
                Track theTrack = new Track(trackTitle, time);
                result.addTrack(theTrack);
                System.out.println("new Track added");
            }
            else
                System.out.println("cannot add Track");            
        }
        else
            System.out.println("Disc not found");
    }

    /**
    * lists all Artists
    *
    */
    public void UCListArtists()
    {
        System.out.println("Artists:");
        for (int i=0;i<numberOfArtists;i++)
        {
            System.out.println(i + ":" +
            artists[i].getName());
        }
    }

    /**
    * lists all Discs
    *
    */
    public void UCListDiscs()
    {
        System.out.println("Discs:");
        for (int i=0;i<numberOfDiscs;i++)
        {
            System.out.println(i + ":" +
            discs[i].getCatalogNumber() + ", "
                + discs[i].getTitle() + ", by "
                + discs[i].getArtist().getName());
        }
    }

    public void UCListTracksForDisc(String discCatalogNumber)
    {
        Disc result = getDiscForCatalogNumber(discCatalogNumber);
        if (result != null)
        {
            System.out.println("Discs:");
            for (int i=0;i<result.numberOfTracks;i++)
            {
                System.out.println(i + ":" +
                    result.tracks[i].getTitle());
            }
        }
        else
            System.out.println("Disc not found");
    }

    // UTILITIES //

    /**
    * getArtistForName - returns an Artist for
    * a specified artist name
    *
    * @param name string containing the
    * name of an Artist
    * @return the Artist object
    * with the specified name
    */
    private Artist getArtistForName(String name)
    {
        int i = 0;
        int found = 0;
        while (i<numberOfArtists && found==0)
        {
            if (name.compareTo(artists[i].getName()) == 0)
                found = 1;
            i++;
        }
        if (found == 1) return artists[i-1];
        else return null;
    }


    /**
    * getDiscForCatalogNumber- returns a Disc for
    * a specified catalog number
    *
    * @param discCatalogNumber string containing
    * the catalog number of a disc
    * @return the Disc object with the specified name
    */
    private Disc getDiscForCatalogNumber(String discCatalogNumber)
    {
        int i = 0;
        int found = 0;
        while (i<numberOfDiscs && found==0)
        {
            if (discCatalogNumber.compareTo(discs[i].getCatalogNumber()) == 0)
                found = 1;
            i++;
        }
        if (found == 1) return discs[i-1];
        else return null;
    }

    /**
    * saves data to disc
    *
    */
    public void saveCatalog()
    {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        // create Catalog object to hold all data
        Catalog catalog = new Catalog();
        catalog.artists = artists;
        catalog.discs = discs;
        try
        {
            // open file in current project directory
            File file = new File("artists.ser");
            String fullPath = file.getAbsolutePath();
            System.out.println("Using file:" + fullPath);
            fos = new FileOutputStream(fullPath);
            // open output stream and store catalog
            out = new ObjectOutputStream(fos);
            out.writeObject(catalog);
            // close stream
            out.close();
        }
        catch(Exception e)
        {
            System.out.println("Could not save:" +
            e.toString());
        }
        System.out.println("Data saved to file");
    }

    /**
    * restores data from disc
    *
    */
    public void restoreCatalog()
    {
        FileInputStream fis = null;
        ObjectInputStream in = null;
        Catalog catalog = null;
        try
        {
            // open the file
            File file = new File("artists.ser");
            String fullPath = file.getAbsolutePath();
            System.out.println("Using file:" + fullPath);
            fis = new FileInputStream(fullPath);
            // open input stream and retrieve data as a
            // Catalog object
            in = new ObjectInputStream(fis);
            catalog = (Catalog)in.readObject();
            // get artists and discs arrays from catalog
            if (catalog.artists != null)
            artists = catalog.artists;
            if (catalog.discs != null)
            discs = catalog.discs;

            // set number of artists and discs
            while (artists[numberOfArtists] != null)
                numberOfArtists++;

            while (discs[numberOfDiscs] != null)
            numberOfDiscs++;

            // close stream
            in.close();
            System.out.println("Data restored from file");
        }
        catch(Exception e)
        {
            System.out.println("Could not restore:" +
            e.toString());
        }
    }
}
