
public class Controller {

    // create the Catalog MODEL
    Catalog catalog = new Catalog();

    /**
     * UC1
     */
    public void UCAddArtist(String artistName) {
        catalog.addArtist(artistName);
    }

    /**
     * UC 2
     */
    public void UCListArtists() {
        catalog.listArtists();
    }

    /**
     * UC 3
     */
    public void UCAddDisc(String artistName, String discCatalogNumber, String discTitle) {
        catalog.addDisc(artistName, discCatalogNumber, discTitle);
    }

    /**
     * UC 4
     */
    public void UCListDiscs() {
        catalog.listDiscs();
    }

    /**
     * UC 5
     */
    public void UCAddTrack(String discCatalogNumber, String trackTitle, double time) {
        catalog.addTrack(discCatalogNumber, trackTitle, time);
    }

    /**
     * UC 6
     */
    public void UCListTracksForDisc(String discCatalogNumber) {
        catalog.listTracksForDisc(discCatalogNumber);
    }

    // UTILITIES //
    /**
     * restores data from disc  UC 7
     *
     */
    public void UCrestoreCatalog() {
        catalog.restoreCatalog();
    }

    /**
     * saves data to disc  UC 8
     *
     */
    public void UCsaveCatalog() {
        catalog.saveCatalog();
    }
}
