
public class View {

    public void showSelection() {
        System.out.println("*** Welcome to Moview Company System ***");

        System.out.println("Enter 1 for adding Artist:");
        System.out.println("Enter 2 for listing Artists:");
        System.out.println("Enter 3 for adding Disc:");
        System.out.println("Enter 4 for listing Discs:");
        System.out.println("Enter 5 for adding Track for Disc:");
        System.out.println("Enter 6 for listing Tracks for Disc:");
        System.out.println("Ener  9 to Exit");

    }//end showSelection
}
