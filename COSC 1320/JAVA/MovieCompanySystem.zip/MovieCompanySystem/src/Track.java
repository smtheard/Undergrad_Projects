
import java.io.*;

public class Track implements Serializable {

    private String title;   //1
    private double time;    //2

    public Track() {
        title = "";
        time = 0.00;
    }

    public Track(String title, double time) {
        this.title = title;
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getTime() {
        return time;
    }

    public void setTime(Double time) {
        this.time = time;
    }
}
