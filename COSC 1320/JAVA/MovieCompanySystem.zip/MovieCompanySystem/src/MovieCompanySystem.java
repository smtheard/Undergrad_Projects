import java.util.*;

public class MovieCompanySystem {

    public static void main(String[] args) {

        // Instantiate Controller
        Controller control = new Controller();
        // Restore Catalog UC 7
        control.UCrestoreCatalog();

        // Instantiate View
        View view = new View();

        view.showSelection();
        Scanner console = new Scanner(System.in);
        int choice;  //variable to hold the selection

        String artist;
        String disc;
        String track;
        String discCatalogNumber;
        double time;

        choice = console.nextInt();
        while (choice != 9)
        {
            switch (choice)
            {
                case 1:  // UC 1 UCAddArtist
                    System.out.println("Enter Artist Name");

                    artist = console.next();
                    control.UCAddArtist(artist);
                    break;

                case 2:  // UC 2 UCListArtist
                    control.UCListArtists();
                    break;

                case 3:  // UC 3 UCAddDisc for Artist and for discCatalogNumber
                    
                    System.out.println("Enter Artist Name");

                    artist = console.next();

                    System.out.println("Enter Catalog Number");

                    discCatalogNumber = console.next();

                    System.out.println("Enter Disc Name");

                    disc = console.next();

                    control.UCAddDisc(artist, discCatalogNumber, disc);
                    break;

                case 4: // UC 4
                    control.UCListDiscs();
                    break;

                case 5:  // UC 5
                    System.out.println("Enter Catalog Number");

                    discCatalogNumber = console.next();

                    System.out.println("Enter Track Title");

                    track = console.next();

                    System.out.println("Enter Track Duration");

                    time = console.nextDouble();

                    control.UCAddTrack(discCatalogNumber, track, time);
                    break;

                case 6:  // UC 6
                    System.out.println("Enter Catalog Number");

                    discCatalogNumber = console.next();
                    control.UCListTracksForDisc(discCatalogNumber);
                    break;

                default:
                    System.out.println("Invalid Selection");
            }//end switch

            view.showSelection();
            choice = console.nextInt();
        }//end while


        // Add Artist
        control.UCAddArtist("Miles Davis");

        // Step 4.3
        // Add Disc for this artist
        control.UCAddDisc("Miles Davis", "CD01", "Tutu");

        // Step 4.4
        // Add track for this disc
        control.UCAddTrack("CD01", "Portia", 3.34);

        // Step 4.5
        // List artists
        control.UCListArtists();

        // Step 4.5
        // List discs
        control.UCListDiscs();

        // Step 4.6
        // List tracks for disc BN01
        control.UCListTracksForDisc("BN01");

        // Step 4.7
        // Add tutu
        control.UCAddTrack("CD01", "Tutu", 4.56);

        // Step 4.7
        // Add Tomaas
        control.UCAddTrack("CD01", "Tomaas", 3.56);

        // Step 4.7
        // Add Disc for this artist
        control.UCAddDisc("Miles Davis", "CD02", "Kind of Blue");

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD02", "So What", 4.54);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD02", "Freddie Freeloader", 5.25);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD02", "Blue in Green", 2.56);

        // Step 4.7
        // Add Artist
        control.UCAddArtist("John Coltrane");

        // Step 4.7
        // Add Disc for this artist
        control.UCAddDisc("John Coltrane", "CD03", "Blue Train");

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD03", "Blue Train", 5.15);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD03", "Moments Notice", 5.52);

        // Step 4.7
        // Add track for this disc
        control.UCAddTrack("CD03", "Locomotion", 6.18);



        // Save Catalog UC 8
        control.UCsaveCatalog();


    }
}
