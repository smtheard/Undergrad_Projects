
import java.io.*;

public class Disc extends Track implements Serializable {

    protected static int MAX_TRACKS = 10;                //1
    private String discCatalogNumber;                    //2
    private int numberOfTracks;                          //3
    private Track[] tracks = new Track[MAX_TRACKS];      //4
    private Artist artist;                               //5

    public Disc() {
    }

    public Disc(Artist artist, String catalogNumber, String title) {
        this.artist = artist;
        this.discCatalogNumber = catalogNumber;
        setTitle(title);
    }

    public String getDiskCatalogNumber() {
        return discCatalogNumber;
    }

    public int getNumberofTracks() {
        // This line was bugged
        // Case sensitivity issue
        return numberOfTracks;
    }

    public Track[] getTracks() {
        return tracks;
    }

    public Artist getArtist() {
        return artist;
    }

    public Track getTrack(int i) {
        return tracks[i];
    }

    public void addTrack(Track track) {
        tracks[numberOfTracks] = track;
        numberOfTracks++;
    }
}
