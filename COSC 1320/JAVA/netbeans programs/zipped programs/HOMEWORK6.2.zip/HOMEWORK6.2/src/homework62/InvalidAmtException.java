
package homework62;

public class InvalidAmtException extends Exception
{
    public InvalidAmtException()
    {
        super();
    }
    public InvalidAmtException(String message)
    {
        super(message);
    }
}
